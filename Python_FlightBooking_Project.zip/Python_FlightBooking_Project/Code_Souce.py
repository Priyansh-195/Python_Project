import random
import re
import datetime

class Flight_Ticket_Booking2:
    d = ['IndiGo', 'AirIndia', 'Akasa Air', 'Vistara Airlines', 'GoAir']
    i = ['British Airways', 'Eithad Airways', 'Qatar Airways', 'Emirates', 'IndiGo']
    c = ['Economy', 'Business', 'First Class']
    w = ['One way', 'Return']
    p = ['Credit card', 'Debit card']
    n = []
    valid = {'user': '1234'}

    def login(self):
        a = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*/?'
        print("\n**WELCOME TO FLIGHT BOOKING SYSTEM*")
        acc = input("\nDO YOU HAVE AN ACCOUNT (Y/N): ")
        e = []
        if acc.lower() in ['y', 'yes']:
            cnt = 0
            flag = True
            while flag:
                if cnt < 2:
                    user = input('Enter username: ')
                    pas = input("ENTER YOUR PASSWORD: ")
                    if user in self.valid and self.valid[user] == pas:
                        print("\n-------LOGIN SUCCESSFUL-------")
                        self.menu()
                        flag = False
                        break
                    else:
                        print('Invalid Username or Password.')
                    cnt += 1
                else:
                    print('Username and Password not found')
                    break
        else:
            nam = input("\nENTER YOUR FULL NAME: ")
            flag = True
            while flag:
                pn = input('\nEnter Mobile number: ')
                if pn.isdigit() and len(pn) == 10:
                    print('Mobile number verification successful....')
                    flag = False
                else:
                    print('Enter valid Mobile number')
            username = input('Enter a username: ')
            while True:
                email = input("\nENTER YOUR EMAIL ID: ")
                e_pat = re.compile(r'^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$')
                if re.match(e_pat, email):
                    break
                else:
                    print('Enter valid email')
            passw = input("\nENTER YOUR PASSWORD: ")
            self.valid[username] = passw
            print("\n-------YOUR ACCOUNT IS CREATED SUCCESSFULLY-------")
            self.login()

    def menu(self):
        fg = True
        while fg:
            print('Press 1. For Domestic flight ')
            print('Press 2. For International flight ')
            select = int(input('Enter your choice: '))
            if select in [1, 2]:
                fg = False
            else:
                print("Invalid.....\nPlease enter valid choice")
        if select == 1:
            domestic().select()
        if select == 2:
            international().select()

class domestic(Flight_Ticket_Booking2):
    def __init__(self):
        self.departure = 'none'
        self.arrival = 'none'
        self.passenger = 'none'
        self.total = 'none'
        self.name = 'none'
        self.age = 'none'
        self.aadhaar_no = 'none'
        self.gender = 'none'
        self.booknm = 'none'
        self.fly = 'none'
        self.mob_no = 'none'
        self.dt = 'none'
        self.returnn = 'none'
        self.a = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*/?'
        self.n = '0123456789#@$%^&*/?'
        self.nm= []
        self.ag = []
        self.adh = []
        self.gn = []
        self.num = []

    def select(self):
        while True:
            self.dt = input('\nEnter date of departure in (dd-mm-yyyy) form: ')
            try:
                datetime.datetime.strptime(self.dt, '%d-%m-%Y')
                break
            except ValueError:
                print("Incorrect date format, should be dd-mm-yyyy")
        flag12 = True
        while flag12:
            self.departure = input("\nENTER YOUR DEPARTURE LOCATION: ")
            self.arrival = input("\nENTER YOUR ARRIVAL LOCATION: ")
            if self.arrival != self.departure and self.departure.isalpha() and self.arrival.isalpha():
                flag12 = False
            else:
                print('Enter valid arrival or departure location')
        self.menu()
        con = input("\nWOULD YOU LIKE TO CONTINUE (Y/N): ")
        if con.lower() in ['n', 'no']:
            self.select()
        elif con.lower() in ['y', 'yes']:
            flag10 = True
            while flag10:
                self.fly = int(input("\nENTER A FLIGHT NAME YOU WANT (Select from the numbers displayed above): "))
                if 1 <= self.fly <= len(self.d):
                    self.pass_data()
                    flag10 = False
                else:
                    print('Enter valid input')
        else:
            print('Enter valid input')

    def pass_data(self):
        self.passenger = int(input("\nENTER A NUMBER OF PASSENGERS: "))
        self.booknm = input('\nEnter name of booking organization or person: ')
        for i in range(self.passenger):
            print('\nENTER DATA OF PASSENGER', i + 1, ':')
            self.name = input("\nENTER NAME OF PASSENGER: ")
            self.nm.append(self.name)
            self.age = int(input(f"\nENTER THE AGE OF {self.name}: "))
            self.ag.append(self.age)
            flag4 = True
            while flag4:
        
                self.mob_no = input('\nEnter Mobile number: ')
                if self.mob_no.isdigit() and len(self.mob_no) == 10:
                    print('Mobile number verification successful....')
                    flag4 = False
                else:
                    print('Enter valid Mobile number')
            self.num.append(self.mob_no)
            flag = True
            while flag:
                self.aadhaar_no = input('\nEnter Aadhaar card number: ')
                if self.aadhaar_no.isdigit() and len(self.aadhaar_no) == 12:
                    print('Aadhaar card verification successful....')
                    flag = False
                else:
                    print('Enter valid Aadhaar card number')
            self.adh.append(self.aadhaar_no)
            flag1 = True
            while flag1:
                self.gender = input('\nEnter Male or Female (M/F): ').lower()
                if self.gender in ['male', 'female', 'm', 'f']:
                    flag1 = False
                else:
                    print('Enter valid input')
            self.gn.append(self.gender)
        y = random.randint(5000, 10000)
        print(y)
        flag2 = True
        while flag2:
            print("\nCHOOSE THE CLASS YOU WANT:")
            print("1. ECONOMY CLASS")
            print("2. BUSINESS CLASS (+20% CHARGES)")
            print("3. FIRST CLASS (+40% CHARGES)")
            self.clss = int(input('Enter class: '))
            if self.clss in [1, 2, 3]:
                flag2 = False
            else:
                print("Invalid input\nPlease enter from the given choices")
        if self.clss == 1:
            self.total = y * self.passenger
        elif self.clss == 2:
            self.total = int((y * self.passenger) * 1.2)
        elif self.clss == 3:
            self.total = int((y * self.passenger) * 1.4)
        self.way()
        flag13 = True
        while flag13:
            wy = int(input('\nEnter way (1 for One way, 2 for Return): '))
            if wy in [1, 2]:
                flag13 = False
            else:
                print('Enter valid input')
        if wy == 1:
            print(f'The price of {self.c[self.clss - 1]} Class for one way of {self.passenger} passenger(s) is ₹{self.total}')
            self.payment()
            flag14 = True
            while flag14:
                pymt = int(input('Press the payment mode (1 for Credit card, 2 for Debit card): '))
                if pymt in [1, 2]:
                    flag14 = False
                else:
                    print('Enter valid input')
            if pymt == 1:
                self.creditCard()
            elif pymt == 2:
                self.debitCard()
            print(f'The amount to be paid of {self.c[self.clss - 1]} Class for one way of {self.passenger} passenger(s) is ₹{self.total}')
            amt = int(input('Enter Amount: '))
            while amt != self.total:
                print('Enter proper amount')
                amt = int(input('Enter Amount: '))
            self.ticketprnt()
            self.display_booking_details()
            print('Payment successful')
        elif wy == 2:
            self.returnn = input('Enter Return Date (format: dd-mm-yyyy): ')
            print(f'The price of {self.c[self.clss - 1]} Class for return of {self.passenger} passenger(s) is ₹{int(self.total * 1.5)}')
            self.total = int(self.total * 1.5)
            self.payment()
            flag14 = True
            while flag14:
                pymt = int(input('Press the payment mode (1 for Credit card, 2 for Debit card): '))
                if pymt in [1, 2]:
                    flag14 = False
                else:
                    print('Enter valid input')
            if pymt == 1:
                self.creditCard()
            elif pymt == 2:
                self.debitCard()
            print(f'The amount to be paid of {self.c[self.clss - 1]} Class for return of {self.passenger} passenger(s) is ₹{self.total}')
            amt = int(input('Enter Amount: '))
            while amt != self.total:
                print('Enter proper amount')
                amt = int(input('Enter Amount: '))
            self.ticketprnt()
            self.display_booking_details()
            print('Payment successful')

    def menu(self):
        print('The flight data is')
        for i in range(len(self.d)):
            print(f'Press {i + 1}: For {self.d[i]}')

    def way(self):
        print('Choose the way you want to select')
        for i in range(len(self.w)):
            print(f'Press {i + 1}: For {self.w[i]}')

    def payment(self):
        print('Choose the way of payment')
        for i in range(len(self.p)):
            print(f'Press {i + 1}: For {self.p[i]}')

    def creditCard(self):
        flag = True
        while flag:
            credit_no = input('\nEnter Credit card number: ')
            if credit_no.isdigit() and 16 <= len(credit_no) < 19:
                print('Credit card verification successful....')
                flag = False
            else:
                print('Enter valid Credit card number')

    def debitCard(self):
        flag = True
        while flag:
            debit_no = input('\nEnter Debit card number: ')
            if debit_no.isdigit() and len(debit_no) == 16:
                print('Debit card verification successful....')
                flag = False
            else:
                print('Enter valid Debit card number')

    def ticketprnt(self):
        with open(self.booknm + '.txt', 'a') as f:
            f.write("*" * 40 + "\n")
            f.write("* {:^36} *\n".format("TICKET"))
            f.write("*" * 40 + "\n")
            for i in range(self.passenger):
                f.write(f"Flight  : {self.d[self.fly - 1]}\n")
                f.write(f"Departure : {self.departure}\n")
                f.write(f"Arrival : {self.arrival}\n")
                if self.returnn != 'none':
                    f.write(f"From : {self.dt}\n")
                    f.write(f"Return : {self.returnn}\n")
                else:
                    f.write(f"Date : {self.dt}\n")
                f.write(f"Class : {self.c[self.clss - 1]}\n")
                f.write(f"Name : {self.nm[i]}\n")
                f.write(f"Age : {self.ag[i]}\n")
                f.write(f"Mobile = {self.num[i]}\n")
                f.write(f"Gender = {self.gn[i]}\n")
                f.write('\n')
                f.write('\n')
            f.write(f'Price : {self.total}\n')

    def display_booking_details(self):
        print("\n-------BOOKING DETAILS-------")
        print(f"Flight  : {self.d[self.fly - 1]}")
        print(f"Departure : {self.departure}")
        print(f"Arrival : {self.arrival}")
        if self.returnn != 'none':
            print(f"From : {self.dt}")
            print(f"Return : {self.returnn}")
        else:
            print(f"Date : {self.dt}")
        print(f"Class : {self.c[self.clss - 1]}")
        for i in range(self.passenger):
            print(f"\nPassenger {i + 1} Details:")
            print(f"Name : {self.nm[i]}")
            print(f"Age : {self.ag[i]}")
            print(f"Mobile : {self.num[i]}")
            print(f"Gender : {self.gn[i]}")
        print(f"Total Price : ₹{self.total}")

class international(Flight_Ticket_Booking2):
    def __init__(self):
        self.departure = 'none'
        self.arrival = 'none'
        self.passenger = 'none'
        self.total = 'none'
        self.name = 'none'
        self.age = 'none'
        self.aadhaar_no = 'none'
        self.gender = 'none'
        self.booknm = 'none'
        self.mob_no = 'none'
        self.dt = 'none'
        self.a = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*/?'
        self.n = '0123456789#@$%^&*/?'
        self.nm = []
        self.ag = []
        self.adh = []
        self.gn = []
        self.num = []
        self.returnn = 'none'
        self.fly = 'none'
        self.clss = 'none'

    def select(self):
        while True:
            self.dt = input('\nEnter date of departure in (dd-mm-yyyy) form: ')
            try:
                datetime.datetime.strptime(self.dt, '%d-%m-%Y')
                break
            except ValueError:
                print("Incorrect date format, should be dd-mm-yyyy")
        flag12 = True
        while flag12:
            self.departure = input("\nENTER YOUR DEPARTURE LOCATION: ")
            self.arrival = input("\nENTER YOUR ARRIVAL LOCATION: ")
            if self.arrival != self.departure and self.departure.isalpha() and self.arrival.isalpha():
                flag12 = False
            else:
                print('Enter valid arrival or departure location')
        self.menu()
        con = input("\nWOULD YOU LIKE TO CONTINUE (Y/N): ")
        if con.lower() in ['n', 'no']:
            self.select()
        elif con.lower() in ['y', 'yes']:
            flag10 = True
            while flag10:
                self.fly = int(input("\nENTER A FLIGHT NAME YOU WANT (Select from the numbers displayed above): "))
                if 1 <= self.fly <= len(self.i):
                    self.pass_data()
                    flag10 = False
                else:
                    print('Enter valid input')
        else:
            print('Enter valid input')

    def pass_data(self):
        self.passenger = int(input("\nENTER A NUMBER OF PASSENGERS: "))
        self.booknm = input('\nEnter name of booking organization or person: ')
        for i in range(self.passenger):
            print('\nENTER DATA OF PASSENGER', i + 1, ':')
            self.name = input("\nENTER NAME OF PASSENGER: ")
            self.nm.append(self.name)
            self.age = int(input(f"\nENTER THE AGE OF {self.name}: "))
            self.ag.append(self.age)
            flag4 = True
            while flag4:
                self.mob_no = input('\nEnter Mobile number: ')
                if self.mob_no.isdigit() and len(self.mob_no) == 10:
                    print('Mobile number verification successful....')
                    flag4 = False
                else:
                    print('Enter valid Mobile number')
            self.num.append(self.mob_no)
            flag = True
            while flag:
                self.aadhaar_no = input('\nEnter Aadhaar card number: ')
                if self.aadhaar_no.isdigit() and len(self.aadhaar_no) == 12:
                    print('Aadhaar card verification successful....')
                    flag = False
                else:
                    print('Enter valid Aadhaar card number')
            self.adh.append(self.aadhaar_no)
            flag1 = True
            while flag1:
                self.gender = input('\nEnter Male or Female (M/F): ').lower()
                if self.gender in ['male', 'female', 'm', 'f']:
                    flag1 = False
                else:
                    print('Enter valid input')
            self.gn.append(self.gender)
        y = random.randint(80000, 200000)
        print(y)
        flag2 = True
        while flag2:
            print("\nCHOOSE THE CLASS YOU WANT:")
            print("1. ECONOMY CLASS")
            print("2. BUSINESS CLASS (+20% CHARGES)")
            print("3. FIRST CLASS (+40% CHARGES)")
            self.clss = int(input('Enter class: '))
            if self.clss in [1, 2, 3]:
                flag2 = False
            else:
                print("Invalid input\nPlease enter from the given choices")
        if self.clss == 1:
            self.total = y * self.passenger
        elif self.clss == 2:
            self.total = int((y * self.passenger) * 1.2)
        elif self.clss == 3:
            self.total = int((y * self.passenger) * 1.4)
        self.way()
        flag13 = True
        while flag13:
            wy = int(input('\nEnter way (1 for One way, 2 for Return): '))
            if wy in [1, 2]:
                flag13 = False
            else:
                print('Enter valid input')
        if wy == 1:
            print(f'The price of {self.c[self.clss - 1]} Class for one way of {self.passenger} passenger(s) is ₹{self.total}')
            self.payment()
            flag14 = True
            while flag14:
                pymt = int(input('Press the payment mode (1 for Credit card, 2 for Debit card): '))
                if pymt in [1, 2]:
                    flag14 = False
                else:
                    print('Enter valid input')
            if pymt == 1:
                self.creditCard()
            elif pymt == 2:
                self.debitCard()
            print(f'The amount to be paid of {self.c[self.clss - 1]} Class for one way of {self.passenger} passenger(s) is ₹{self.total}')
            amt = int(input('Enter Amount: '))
            while amt != self.total:
                print('Enter proper amount')
                amt = int(input('Enter Amount: '))
            self.ticketprnt()
            self.display_booking_details()
            print('Payment successful')
        elif wy == 2:
            self.returnn = input('Enter Return Date (format: dd-mm-yyyy): ')
            print(f'The price of {self.c[self.clss - 1]} Class for return of {self.passenger} passenger(s) is ₹{int(self.total * 1.5)}')
            self.total = int(self.total * 1.5)
            self.payment()
            flag14 = True
            while flag14:
                pymt = int(input('Press the payment mode (1 for Credit card, 2 for Debit card): '))
                if pymt in [1, 2]:
                    flag14 = False
                else:
                    print('Enter valid input')
            if pymt == 1:
                self.creditCard()
            elif pymt == 2:
                self.debitCard()
            print(f'The amount to be paid of {self.c[self.clss - 1]} Class for return of {self.passenger} passenger(s) is ₹{self.total}')
            amt = int(input('Enter Amount: '))
            while amt != self.total:
                print('Enter proper amount')
                amt = int(input('Enter Amount: '))
            self.ticketprnt()
            self.display_booking_details()
            print('Payment successful')

    def menu(self):
        print('The flight data is')
        for j in range(len(self.i)):
            print(f'Press {j + 1}: For {self.i[j]}')

    def way(self):
        print('Choose the way you want to select')
        for i in range(len(self.w)):
            print(f'Press {i + 1}: For {self.w[i]}')

    def payment(self):
        print('Choose the way of payment')
        for i in range(len(self.p)):
            print(f'Press {i + 1}: For {self.p[i]}')

    def creditCard(self):
        flag = True
        while flag:
            credit_no = input('\nEnter Credit card number: ')
            if credit_no.isdigit() and 16 <= len(credit_no) < 19:
                print('Credit card verification successful....')
                flag = False
            else:
                print('Enter valid Credit card number')

    def debitCard(self):
        flag = True
        while flag:
            debit_no = input('\nEnter Debit card number: ')
            if debit_no.isdigit() and len(debit_no) == 16:
                print('Debit card verification successful....')
                flag = False
            else:
                print('Enter valid Debit card number')

    def ticketprnt(self):
        with open(self.booknm + '.txt', 'a') as f:
            f.write("*" * 40 + "\n")
            f.write("* {:^36} *\n".format("TICKET"))
            f.write("*" * 40 + "\n")
            for i in range(self.passenger):
                f.write(f"Flight  : {self.i[self.fly - 1]}\n")
                f.write(f"Departure : {self.departure}\n")
                f.write(f"Arrival : {self.arrival}\n")
                if self.returnn != 'none':
                    f.write(f"From : {self.dt}\n")
                    f.write(f"Return : {self.returnn}\n")
                else:
                    f.write(f"Date : {self.dt}\n")
                f.write(f"Class : {self.c[self.clss - 1]}\n")
                f.write(f"Name : {self.nm[i]}\n")
                f.write(f"Age : {self.ag[i]}\n")
                f.write(f"Mobile = {self.num[i]}\n")
                f.write(f"Gender = {self.gn[i]}\n")
                f.write('\n')
                f.write('\n')
            f.write(f'Price : {self.total}\n')

    def display_booking_details(self):
        print("\n-------BOOKING DETAILS-------")
        print(f"Flight  : {self.i[self.fly - 1]}")
        print(f"Departure : {self.departure}")
        print(f"Arrival : {self.arrival}")
        if self.returnn != 'none':
            print(f"From : {self.dt}")
            print(f"Return : {self.returnn}")
        else:
            print(f"Date : {self.dt}")
        print(f"Class : {self.c[self.clss - 1]}")
        for i in range(self.passenger):
            print(f"\nPassenger {i + 1} Details:")
            print(f"Name : {self.nm[i]}")
            print(f"Age : {self.ag[i]}")
            print(f"Mobile : {self.num[i]}")
            print(f"Gender : {self.gn[i]}")
        print(f"Total Price : ₹{self.total}")

f = Flight_Ticket_Booking2()
f.login()