import csv
import os
import matplotlib.pyplot as plt
from datetime import datetime

EXPENSES_FILE = "expenses.csv"

def initialize_file():
    if not os.path.exists(EXPENSES_FILE):
        with open(EXPENSES_FILE, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Date", "Category", "Amount", "Description"])

def is_valid_date(date_str):
    """Validates the date format (DD-MM-YYYY)."""
    try:
        datetime.strptime(date_str, "%d-%m-%Y")
        return True
    except ValueError:
        return False

def get_valid_date():
    """Prompts the user until they enter a valid date."""
    while True:
        date = input("Enter date (DD-MM-YYYY): ")
        if is_valid_date(date):
            return date
        else:
            print("Invalid date format! Please enter in DD-MM-YYYY format.")

def get_valid_amount():
    """Prompts the user until they enter a valid amount."""
    while True:
        amount = input("Enter amount: ")
        try:
            return float(amount) 
        except ValueError:
            print("Invalid amount! Please enter a numeric value.")

def add_expense():
    """Collects user input and adds an expense to the file."""
    date = get_valid_date()
    category = input("Enter category: ")
    amount = get_valid_amount()
    description = input("Enter description: ")

    with open(EXPENSES_FILE, mode="a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([date, category, amount, description])
    print(" Expense added successfully.")

def edit_expense():
    """Edits an expense by selecting a date and modifying its details."""
    target_date = get_valid_date()

    if not os.path.exists(EXPENSES_FILE):
        print("No expenses to edit.")
        return
    
    expenses = []
    updated = False
    with open(EXPENSES_FILE, mode="r") as file:
        reader = csv.reader(file)
        header = next(reader)
        expenses.append(header)

        for row in reader:
            if row[0] == target_date:
                print(f"Editing: {row}")
                new_category = input(f"Enter new category (leave blank to keep '{row[1]}'): ") or row[1]
                new_amount = input(f"Enter new amount (leave blank to keep '{row[2]}'): ") or row[2]
                new_description = input(f"Enter new description (leave blank to keep '{row[3]}'): ") or row[3]
                expenses.append([target_date, new_category, new_amount, new_description])
                updated = True
            else:
                expenses.append(row)

    if updated:
        with open(EXPENSES_FILE, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerows(expenses)
        print(f" Expense on {target_date} updated successfully.")
    else:
        print(f"No expense found on {target_date}.")

def search_expense():
    """Searches expenses by date or category."""
    print("Search by: 1 Date  2 Category")
    search_type = input("Enter choice: ")

    if search_type == "1":
        search_value = get_valid_date()
        column = 0  # Date column
    elif search_type == "2":
        search_value = input("Enter category: ").strip()
        column = 1  # Category column
    else:
        print("Invalid choice.")
        return

    if not os.path.exists(EXPENSES_FILE):
        print("No expenses found.")
        return

    found = False
    with open(EXPENSES_FILE, mode="r") as file:
        reader = csv.reader(file)
        next(reader)  # Skip header
        for row in reader:
            if row[column] == search_value:
                print(" | ".join(row))
                found = True

    if not found:
        print("No matching expenses found.")

def calculate_total_expenses():
    """Calculates and displays the total amount spent."""
    if not os.path.exists(EXPENSES_FILE):
        print("No expenses recorded yet.")
        return

    total = 0
    with open(EXPENSES_FILE, mode="r") as file:
        reader = csv.reader(file)
        next(reader)  # Skip header
        for row in reader:
            total += float(row[2])

    print(f" Total expenses: ${total:.2f}")



def view_expenses():
    """Displays all expenses."""
    if not os.path.exists(EXPENSES_FILE):
        print("No expenses found.")
        return
    
    with open(EXPENSES_FILE, mode="r") as file:
        reader = csv.reader(file)
        for row in reader:
            print(" | ".join(row))

def delete_expense():
    """Deletes expenses for a given date."""
    target_date = get_valid_date()

    if not os.path.exists(EXPENSES_FILE):
        print("No expenses to delete.")
        return
    
    updated_expenses = []
    with open(EXPENSES_FILE, mode="r") as file:
        reader = csv.reader(file)
        header = next(reader)
        updated_expenses.append(header)

        for row in reader:
            if row[0] != target_date:
                updated_expenses.append(row)
    
    with open(EXPENSES_FILE, mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(updated_expenses)
    print()
    print(f" Expenses on {target_date} deleted successfully.")

def visualize_expenses():
    """Visualizes total expenses per category using a bar chart."""
    if not os.path.exists(EXPENSES_FILE):
        print("No expenses to visualize.")
        return
    
    expenses = {}
    with open(EXPENSES_FILE, mode="r") as file:
        reader = csv.reader(file)
        next(reader)  # Skip header
        for row in reader:
            category = row[1]
            amount = float(row[2])
            expenses[category] = expenses.get(category, 0) + amount

    if not expenses:
        print("No data to display.")
        return

    # Plotting the data
    categories = list(expenses.keys())
    amounts = list(expenses.values())

    plt.figure(figsize=(9, 5))
    plt.bar(categories, amounts, color='skyblue',edgecolor='black', alpha=0.8 ,width=0.4)
    plt.xlabel("Expense Categories", fontsize=13, fontweight='bold')
    plt.ylabel("Total Amount Spent ($)", fontsize=13, fontweight='bold')
    plt.title(" Your Expense Distribution by Graph ", fontsize=14, fontweight='bold' , color='Red')
    plt.xticks(rotation=30)
    plt.show()

def main():
    initialize_file()
    while True:
        print("\n=== Expense Tracker ===")
        print("1  Add Expense")
        print("2  View Expenses")
        print("3  Delete Expense")
        print("4  Visualize Expenses ")
        print("5  Edit Expense ")
        print("6  Search Expense ")
        print("7  Calculate Total Expenses ")
        print("8  Exit")
        
        choice = input("Enter your choice: ")
        if choice == "1":
            add_expense()
        elif choice == "2":
            view_expenses()
        elif choice == "3":
            delete_expense()
        elif choice == "4":
            visualize_expenses()
        elif choice == "5":
            edit_expense()
        elif choice == "6":
            search_expense()
        elif choice == "7":
            calculate_total_expenses()
        elif choice == "8":
            print(" Exiting... Have a great day!")
            break
        else:
            print("Invalid choice. Please try again.")

if _name_ == "_main_":
    print("   WELCOME !! Your Expense Tracker Program    ")
    main()